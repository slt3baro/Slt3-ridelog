// Dark, rounded, blue-accent look in the spirit of Substreamer.
export const colors = {
  bgTop: '#13242F',
  bgBottom: '#121212',
  card: '#1C1C1E',
  cardSoft: '#232326',
  pill: '#2A2A2D',
  border: '#2C2C30',
  text: '#FFFFFF',
  textDim: '#A5A8AE',
  accent: '#2196F3',
  accentSoft: '#173A57',
  good: '#4CAF50',
  bad: '#EF5350',
  warn: '#FFB300',
  routeDim: '#3A4651',
  second: '#FF8A65',
};

export const radius = { card: 22, pill: 999, tile: 14 };

export const font = {
  h1: { fontSize: 30, fontWeight: '700', color: colors.text },
  h2: { fontSize: 22, fontWeight: '700', color: colors.text },
  title: { fontSize: 17, fontWeight: '600', color: colors.text },
  body: { fontSize: 15, color: colors.textDim },
  small: { fontSize: 12, color: colors.textDim },
  big: { fontSize: 64, fontWeight: '700', color: colors.text },
};
