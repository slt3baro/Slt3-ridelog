import AsyncStorage from '@react-native-async-storage/async-storage';
import { computeStats, decimate, LAT, LON } from './geo';

const RIDES = 'rides:v1'; // array of summaries (no points)
const POINTS = (id) => `ridepoints:${id}`;
const SETTINGS = 'settings:v1';

export const defaultSettings = {
  minStreakKm: 1, // a ride counts for the streak if it is at least this long
  autoPauseKmh: 3.6, // below this speed the ride counts as stopped
  serverUrl: '', // reserved for laptop sync
};

export async function getSettings() {
  try {
    const raw = await AsyncStorage.getItem(SETTINGS);
    return { ...defaultSettings, ...(raw ? JSON.parse(raw) : {}) };
  } catch {
    return defaultSettings;
  }
}
export async function saveSettings(s) {
  await AsyncStorage.setItem(SETTINGS, JSON.stringify(s));
}

export async function getRides() {
  try {
    const raw = await AsyncStorage.getItem(RIDES);
    const list = raw ? JSON.parse(raw) : [];
    return list.sort((a, b) => b.startedAt - a.startedAt);
  } catch {
    return [];
  }
}

export async function getRidePoints(id) {
  const raw = await AsyncStorage.getItem(POINTS(id));
  return raw ? JSON.parse(raw) : [];
}

const round = (n, d) => (n == null ? n : Math.round(n * 10 ** d) / 10 ** d);

function rideName(ms) {
  const h = new Date(ms).getHours();
  const part = h < 5 ? 'Night' : h < 12 ? 'Morning' : h < 17 ? 'Afternoon' : h < 21 ? 'Evening' : 'Night';
  return `${part} ride`;
}

export async function saveRide(points, movingThresholdMps) {
  const compact = points.map((p) => [p[0], round(p[1], 6), round(p[2], 6), round(p[3], 1), round(p[4], 2), p[5]]);
  const stats = computeStats(compact, movingThresholdMps);
  const startedAt = compact[0][0];
  const id = String(startedAt);
  const preview = decimate(compact, 40).map((p) => [p[LAT], p[LON]]);
  const summary = { id, name: rideName(startedAt), startedAt, stats, preview };
  await AsyncStorage.setItem(POINTS(id), JSON.stringify(compact));
  const rides = await getRides();
  await AsyncStorage.setItem(RIDES, JSON.stringify([summary, ...rides.filter((r) => r.id !== id)]));
  return summary;
}

export async function deleteRide(id) {
  const rides = await getRides();
  await AsyncStorage.setItem(RIDES, JSON.stringify(rides.filter((r) => r.id !== id)));
  await AsyncStorage.removeItem(POINTS(id));
}

export async function renameRide(id, name) {
  const rides = await getRides();
  await AsyncStorage.setItem(RIDES, JSON.stringify(rides.map((r) => (r.id === id ? { ...r, name } : r))));
}
