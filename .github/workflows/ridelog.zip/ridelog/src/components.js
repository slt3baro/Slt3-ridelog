import React, { useMemo, useState, useCallback } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import Svg, { Polyline, Circle, Rect, G, Defs, LinearGradient as SvgGradient, Stop, Path, Line } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, font } from './theme';
import { getRides, getSettings, defaultSettings } from './storage';

// ---------- data hook: reloads whenever a screen is focused ----------
export function useAppData() {
  const [data, setData] = useState({ rides: [], settings: defaultSettings, loaded: false });
  useFocusEffect(
    useCallback(() => {
      let alive = true;
      (async () => {
        const [rides, settings] = await Promise.all([getRides(), getSettings()]);
        if (alive) setData({ rides, settings, loaded: true });
      })();
      return () => { alive = false; };
    }, [])
  );
  return data;
}

// ---------- layout ----------
export function Screen({ children, scroll = true, bottomPad = 32 }) {
  const insets = useSafeAreaInsets();
  return (
    <LinearGradient colors={[colors.bgTop, colors.bgBottom]} locations={[0, 0.4]} style={{ flex: 1 }}>
      {scroll ? (
        <ScrollView
          contentContainerStyle={{ paddingTop: insets.top + 12, paddingHorizontal: 16, paddingBottom: bottomPad }}
          showsVerticalScrollIndicator={false}
        >
          {children}
        </ScrollView>
      ) : (
        <View style={{ flex: 1, paddingTop: insets.top + 12, paddingHorizontal: 16 }}>{children}</View>
      )}
    </LinearGradient>
  );
}

export function Card({ children, style, onPress }) {
  const Comp = onPress ? Pressable : View;
  return (
    <Comp onPress={onPress} style={[styles.card, style]}>
      {children}
    </Comp>
  );
}

export function SectionHeader({ title, right }) {
  return (
    <View style={styles.sectionRow}>
      <Text style={font.h2}>{title}</Text>
      {right}
    </View>
  );
}

export function SearchBar({ value, onChangeText, placeholder = 'Search...' }) {
  return (
    <View style={styles.search}>
      <Ionicons name="search" size={22} color={colors.textDim} />
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.textDim}
        style={styles.searchInput}
      />
    </View>
  );
}

export function Pill({ icon, label, selected, onPress }) {
  return (
    <Pressable onPress={onPress} style={[styles.pill, selected && { backgroundColor: colors.accentSoft }]}>
      {icon ? <Ionicons name={icon} size={18} color={selected ? colors.accent : colors.textDim} style={{ marginRight: 8 }} /> : null}
      <Text style={{ color: selected ? colors.accent : colors.text, fontSize: 15, fontWeight: '600' }}>{label}</Text>
    </Pressable>
  );
}

export function IconStat({ icon, value, label, color = colors.accent }) {
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <View style={styles.iconCircle}>
        <Ionicons name={icon} size={26} color={color} />
      </View>
      <Text style={styles.iconValue} numberOfLines={1} adjustsFontSizeToFit>{value}</Text>
      <Text style={font.small}>{label}</Text>
    </View>
  );
}

export function Stat({ label, value, unit, big, color }) {
  return (
    <View style={{ flex: 1 }}>
      <Text style={font.small}>{label}</Text>
      <Text style={[{ fontSize: big ? 30 : 22, fontWeight: '700', color: color || colors.text, marginTop: 2 }]} numberOfLines={1} adjustsFontSizeToFit>
        {value}
        {unit ? <Text style={{ fontSize: 13, color: colors.textDim, fontWeight: '500' }}> {unit}</Text> : null}
      </Text>
    </View>
  );
}

export function Button({ title, icon, onPress, color = colors.accent, style, disabled }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={[styles.button, { backgroundColor: color, opacity: disabled ? 0.4 : 1 }, style]}
    >
      {icon ? <Ionicons name={icon} size={22} color="#fff" style={{ marginRight: 8 }} /> : null}
      <Text style={{ color: '#fff', fontSize: 17, fontWeight: '700' }}>{title}</Text>
    </Pressable>
  );
}

// ---------- route drawing (no map tiles needed, works offline) ----------
// routes: [{ coords: [[lat, lon], ...], color }]. cursor indexes routes[0].coords.
export function RouteView({ routes, height = 240, cursor, follow = false, zoom = 6, radiusPx = 22, style }) {
  const [w, setW] = useState(0);

  const view = useMemo(() => {
    const all = routes.flatMap((r) => r.coords);
    if (!w || all.length < 2) return null;
    const lat0 = all.reduce((s, c) => s + c[0], 0) / all.length;
    const k = Math.cos((lat0 * Math.PI) / 180);
    const proj = (c) => [c[1] * k, -c[0]];
    const pr = all.map(proj);
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const [x, y] of pr) {
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
    }
    const bw = Math.max(maxX - minX, 1e-7), bh = Math.max(maxY - minY, 1e-7);
    const pad = 22;
    const scale = Math.min((w - 2 * pad) / bw, (height - 2 * pad) / bh);
    const ox = (w - bw * scale) / 2 - minX * scale;
    const oy = (height - bh * scale) / 2 - minY * scale;
    const toPx = (c) => { const [x, y] = proj(c); return [x * scale + ox, y * scale + oy]; };
    return { lines: routes.map((r) => ({ ...r, px: r.coords.map(toPx) })) };
  }, [routes, w, height]);

  const z = follow && cursor != null ? zoom : 1;
  let transform = '';
  if (view && follow && cursor != null) {
    const p = view.lines[0].px[Math.min(cursor, view.lines[0].px.length - 1)];
    transform = `translate(${w / 2} ${height / 2}) scale(${z}) translate(${-p[0]} ${-p[1]})`;
  }
  const sw = 4 / z;
  const str = (px) => px.map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const grid = [];
  if (w) {
    for (let x = 40; x < w; x += 40) grid.push(<Line key={`gx${x}`} x1={x} y1={0} x2={x} y2={height} stroke="#ffffff" strokeOpacity={0.04} />);
    for (let y = 40; y < height; y += 40) grid.push(<Line key={`gy${y}`} x1={0} y1={y} x2={w} y2={y} stroke="#ffffff" strokeOpacity={0.04} />);
  }

  return (
    <View
      style={[{ height, borderRadius: radius.card, overflow: 'hidden', backgroundColor: '#15191D' }, style]}
      onLayout={(e) => setW(e.nativeEvent.layout.width)}
    >
      {w > 0 && (
        <Svg width={w} height={height}>
          <Rect x={0} y={0} width={w} height={height} fill="#15191D" />
          {grid}
          {view && (
            <G transform={transform || undefined}>
              {view.lines.map((l, i) => {
                const hasCursor = i === 0 && cursor != null;
                return (
                  <G key={i}>
                    <Polyline
                      points={str(l.px)}
                      fill="none"
                      stroke={hasCursor ? colors.routeDim : l.color}
                      strokeWidth={sw}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    {hasCursor && (
                      <Polyline
                        points={str(l.px.slice(0, cursor + 1))}
                        fill="none"
                        stroke={l.color}
                        strokeWidth={sw * 1.15}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    )}
                  </G>
                );
              })}
              {cursor == null &&
                view.lines.map((l, i) => (
                  <G key={`m${i}`}>
                    <Circle cx={l.px[0][0]} cy={l.px[0][1]} r={5 / z} fill={colors.good} />
                    <Circle cx={l.px[l.px.length - 1][0]} cy={l.px[l.px.length - 1][1]} r={5 / z} fill={colors.bad} />
                  </G>
                ))}
              {cursor != null && (() => {
                const p = view.lines[0].px[Math.min(cursor, view.lines[0].px.length - 1)];
                return (
                  <G>
                    <Circle cx={p[0]} cy={p[1]} r={(radiusPx * 0.7) / z} fill={view.lines[0].color} fillOpacity={0.25} />
                    <Circle cx={p[0]} cy={p[1]} r={7 / z} fill="#fff" stroke={view.lines[0].color} strokeWidth={3 / z} />
                  </G>
                );
              })()}
            </G>
          )}
        </Svg>
      )}
    </View>
  );
}

// Tiny route thumbnail for lists (uses the short preview stored with each ride).
export function RouteThumb({ coords, size = 72, color = colors.accent }) {
  if (!coords || coords.length < 2) {
    return <View style={{ width: size, height: size, borderRadius: 14, backgroundColor: '#15191D' }} />;
  }
  const lat0 = coords.reduce((s, c) => s + c[0], 0) / coords.length;
  const k = Math.cos((lat0 * Math.PI) / 180);
  const pr = coords.map((c) => [c[1] * k, -c[0]]);
  const xs = pr.map((p) => p[0]), ys = pr.map((p) => p[1]);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  const bw = Math.max(maxX - minX, 1e-7), bh = Math.max(maxY - minY, 1e-7);
  const pad = size * 0.14;
  const s = Math.min((size - 2 * pad) / bw, (size - 2 * pad) / bh);
  const ox = (size - bw * s) / 2 - minX * s, oy = (size - bh * s) / 2 - minY * s;
  const pts = pr.map((p) => `${(p[0] * s + ox).toFixed(1)},${(p[1] * s + oy).toFixed(1)}`).join(' ');
  return (
    <View style={{ width: size, height: size, borderRadius: 14, overflow: 'hidden', backgroundColor: '#15191D' }}>
      <Svg width={size} height={size}>
        <Polyline points={pts} fill="none" stroke={color} strokeWidth={size > 100 ? 4 : 3} strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
    </View>
  );
}

// Filled area chart (elevation / speed profile) with an optional playback cursor.
export function Sparkline({ values, color = colors.accent, height = 90, cursorFrac, id = 'sp' }) {
  const [w, setW] = useState(0);
  const path = useMemo(() => {
    if (!w || values.length < 2) return null;
    let min = Math.min(...values), max = Math.max(...values);
    if (max - min < 1e-6) { max = min + 1; }
    const pad = 6;
    const x = (i) => (i / (values.length - 1)) * w;
    const y = (v) => pad + (1 - (v - min) / (max - min)) * (height - 2 * pad);
    let line = `M ${x(0).toFixed(1)} ${y(values[0]).toFixed(1)}`;
    for (let i = 1; i < values.length; i++) line += ` L ${x(i).toFixed(1)} ${y(values[i]).toFixed(1)}`;
    return { line, area: `${line} L ${w} ${height} L 0 ${height} Z` };
  }, [values, w, height]);
  return (
    <View style={{ height, borderRadius: 14, overflow: 'hidden', backgroundColor: '#15191D' }} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      {w > 0 && path && (
        <Svg width={w} height={height}>
          <Defs>
            <SvgGradient id={id} x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={color} stopOpacity={0.45} />
              <Stop offset="1" stopColor={color} stopOpacity={0.02} />
            </SvgGradient>
          </Defs>
          <Path d={path.area} fill={`url(#${id})`} />
          <Path d={path.line} fill="none" stroke={color} strokeWidth={2} />
          {cursorFrac != null && (
            <Line x1={cursorFrac * w} y1={0} x2={cursorFrac * w} y2={height} stroke="#fff" strokeWidth={1.5} strokeOpacity={0.8} />
          )}
        </Svg>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.card, borderRadius: radius.card, padding: 16 },
  sectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 26, marginBottom: 12 },
  search: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.card,
    borderRadius: 20, paddingHorizontal: 16, height: 56, marginBottom: 12,
  },
  searchInput: { flex: 1, marginLeft: 12, color: colors.text, fontSize: 18 },
  pill: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.pill,
    borderRadius: radius.pill, paddingHorizontal: 18, height: 44, marginRight: 10,
  },
  iconCircle: {
    width: 56, height: 56, borderRadius: 28, backgroundColor: colors.accentSoft,
    alignItems: 'center', justifyContent: 'center', marginBottom: 10,
  },
  iconValue: { color: colors.text, fontSize: 22, fontWeight: '700' },
  button: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    height: 56, borderRadius: radius.pill, paddingHorizontal: 22,
  },
});
