// Points are stored compactly as arrays: [timeMs, lat, lon, altitudeM, speedMps, segment]
export const T = 0, LAT = 1, LON = 2, ALT = 3, SPD = 4, SEG = 5;

const R = 6371000;
const rad = (d) => (d * Math.PI) / 180;

export function haversine(a, b) {
  const dLat = rad(b[LAT] - a[LAT]);
  const dLon = rad(b[LON] - a[LON]);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a[LAT])) * Math.cos(rad(b[LAT])) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

const MAX_PLAUSIBLE_MPS = 28; // ~100 km/h: anything faster is a GPS jump
const MAX_GAP_S = 20; // gaps longer than this (signal loss) are not counted

// Speed of one segment between two points (m/s). Prefers the GPS Doppler speed.
function pairSpeed(a, b, d, dt) {
  const v = d / dt;
  const s = b[SPD];
  return s != null && s >= 0 ? s : v;
}

export function computeStats(points, movingThresholdMps = 1.0) {
  let distance = 0, moving = 0, elapsed = 0, maxSpeed = 0;
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i];
    if (a[SEG] !== b[SEG]) continue;
    const dt = (b[T] - a[T]) / 1000;
    if (dt <= 0 || dt > MAX_GAP_S) continue;
    const d = haversine(a, b);
    if (d / dt > MAX_PLAUSIBLE_MPS) continue;
    elapsed += dt;
    const v = pairSpeed(a, b, d, dt);
    if (v >= movingThresholdMps) {
      distance += d;
      moving += dt;
      if (v > maxSpeed) maxSpeed = v;
    }
  }
  // Elevation gain with a 3 m dead band so GPS noise is not counted as climbing.
  let gain = 0, minAlt = Infinity, maxAlt = -Infinity, ref = null;
  for (const p of points) {
    const alt = p[ALT];
    if (alt == null) continue;
    if (alt < minAlt) minAlt = alt;
    if (alt > maxAlt) maxAlt = alt;
    if (ref == null) { ref = alt; continue; }
    if (alt - ref >= 3) { gain += alt - ref; ref = alt; }
    else if (ref - alt >= 3) { ref = alt; }
  }
  return {
    distance, // meters
    movingTime: moving, // seconds
    elapsed, // seconds (excludes manual pauses and signal gaps)
    avgSpeed: moving > 0 ? distance / moving : 0, // m/s
    maxSpeed, // m/s
    elevGain: gain, // meters
    minAlt: isFinite(minAlt) ? minAlt : 0,
    maxAlt: isFinite(maxAlt) ? maxAlt : 0,
  };
}

// True when the last few seconds of the ride were basically standing still.
export function isAutoPaused(points, thresholdMps = 1.0) {
  if (points.length < 3) return false;
  const last = points[points.length - 1];
  if (Date.now() - last[T] > 6000) return true; // no fresh fix: treat as stopped
  const recent = points.slice(-4);
  return recent.slice(1).every((p, i) => {
    const a = recent[i];
    const dt = Math.max(0.5, (p[T] - a[T]) / 1000);
    return pairSpeed(a, p, haversine(a, p), dt) < thresholdMps;
  });
}

// Per-point series used for replay and charts. dist is cumulative moving distance.
export function buildSeries(points, movingThresholdMps = 1.0) {
  const out = [];
  let dist = 0, t = 0;
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    let speed = 0;
    if (i > 0) {
      const a = points[i - 1];
      const dt = (p[T] - a[T]) / 1000;
      if (a[SEG] === p[SEG] && dt > 0 && dt <= MAX_GAP_S) {
        const d = haversine(a, p);
        if (d / dt <= MAX_PLAUSIBLE_MPS) {
          speed = pairSpeed(a, p, d, dt);
          t += dt;
          if (speed >= movingThresholdMps) dist += d; else speed = 0;
        }
      }
    }
    out.push({ lat: p[LAT], lon: p[LON], alt: p[ALT] ?? 0, speed, dist, t });
  }
  return out;
}

export function decimate(arr, max) {
  if (arr.length <= max) return arr;
  const step = (arr.length - 1) / (max - 1);
  const out = [];
  for (let i = 0; i < max; i++) out.push(arr[Math.round(i * step)]);
  return out;
}

// ---------- formatting ----------
export const kmh = (mps) => mps * 3.6;
export const fmtKm = (m) => (m / 1000).toFixed(m < 10000 ? 2 : 1);
export const fmtSpeed = (mps) => kmh(mps).toFixed(1);
export function fmtDuration(sec) {
  sec = Math.max(0, Math.round(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m`;
  return `${m}:${String(s).padStart(2, '0')}`;
}
export function fmtClock(sec) {
  sec = Math.max(0, Math.round(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  const mm = String(m).padStart(2, '0'), ss = String(s).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${m}:${ss}`;
}
export function fmtDate(ms) {
  return new Date(ms).toLocaleDateString(undefined, {
    weekday: 'short', day: 'numeric', month: 'short',
  });
}
export function fmtTime(ms) {
  return new Date(ms).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

// ---------- streaks & weeks ----------
export const dayKey = (ms) => {
  const d = new Date(ms);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export function computeStreak(rides, minMeters) {
  const days = new Set(rides.filter((r) => r.stats.distance >= minMeters).map((r) => dayKey(r.startedAt)));
  // current streak: counts back from today (or yesterday if you haven't ridden yet today)
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  if (!days.has(dayKey(d.getTime()))) d.setDate(d.getDate() - 1);
  let current = 0;
  while (days.has(dayKey(d.getTime()))) { current++; d.setDate(d.getDate() - 1); }
  // best streak
  const sorted = [...days].sort();
  let best = 0, run = 0, prev = null;
  for (const k of sorted) {
    const cur = new Date(k + 'T12:00:00').getTime();
    run = prev != null && Math.round((cur - prev) / 86400000) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    prev = cur;
  }
  return { current, best, ridden: (ms) => days.has(dayKey(ms)) };
}

// Week starts on Sunday. Returns 7 days, Sun..Sat, of the current week.
export function currentWeek() {
  const now = new Date();
  now.setHours(12, 0, 0, 0);
  const start = new Date(now);
  start.setDate(now.getDate() - now.getDay());
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return { ms: d.getTime(), label: ['S', 'M', 'T', 'W', 'T', 'F', 'S'][i], isToday: dayKey(d.getTime()) === dayKey(now.getTime()) };
  });
}
