import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Alert, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Card, Stat, Pill, RouteView, Sparkline, SectionHeader } from '../components';
import { colors, font } from '../theme';
import { getRides, getRidePoints, deleteRide, getSettings } from '../storage';
import { buildSeries, decimate, fmtKm, fmtSpeed, fmtDuration, fmtClock, fmtDate, fmtTime } from '../geo';

const REPLAY_SECONDS = 28; // a whole ride replays in about this long

export default function RideDetailScreen({ route, navigation }) {
  const { id } = route.params;
  const [ride, setRide] = useState(null);
  const [series, setSeries] = useState([]);
  const [progress, setProgress] = useState(1); // 0..1 through the ride
  const [playing, setPlaying] = useState(false);
  const [follow, setFollow] = useState(true);
  const [rate, setRate] = useState(1);
  const raf = useRef(null);
  const last = useRef(0);
  const prog = useRef(1);

  useEffect(() => {
    (async () => {
      const [rides, settings] = await Promise.all([getRides(), getSettings()]);
      setRide(rides.find((r) => r.id === id) || null);
      const pts = await getRidePoints(id);
      const full = buildSeries(pts, settings.autoPauseKmh / 3.6);
      setSeries(decimate(full, 900));
    })();
  }, [id]);

  const coords = useMemo(() => series.map((s) => [s.lat, s.lon]), [series]);
  const speeds = useMemo(() => series.map((s) => s.speed * 3.6), [series]);
  const alts = useMemo(() => series.map((s) => s.alt), [series]);

  // Replay loop
  useEffect(() => {
    if (!playing) return;
    last.current = Date.now();
    const tick = () => {
      const now = Date.now();
      const dt = (now - last.current) / 1000;
      last.current = now;
      prog.current = Math.min(1, prog.current + (dt * rate) / REPLAY_SECONDS);
      setProgress(prog.current);
      if (prog.current >= 1) { setPlaying(false); return; }
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [playing, rate]);

  const togglePlay = () => {
    if (!playing && prog.current >= 1) { prog.current = 0; setProgress(0); }
    setPlaying((p) => !p);
  };

  const onDelete = () => {
    Alert.alert('Delete ride?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => { await deleteRide(id); navigation.goBack(); } },
    ]);
  };

  if (!ride) {
    return (
      <Screen><Text style={font.body}>Loading...</Text></Screen>
    );
  }

  const idx = series.length ? Math.min(series.length - 1, Math.round(progress * (series.length - 1))) : 0;
  const cur = series[idx];
  const st = ride.stats;
  const showReplay = progress < 1 || playing;

  return (
    <Screen>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 14 }}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={12} style={{ marginRight: 12 }}>
          <Ionicons name="chevron-back" size={28} color={colors.text} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={font.h2} numberOfLines={1}>{ride.name}</Text>
          <Text style={font.body}>{fmtDate(ride.startedAt)} · {fmtTime(ride.startedAt)}</Text>
        </View>
        <Pressable onPress={onDelete} hitSlop={12}>
          <Ionicons name="trash-outline" size={24} color={colors.textDim} />
        </Pressable>
      </View>

      {coords.length > 1 ? (
        <RouteView
          routes={[{ coords, color: colors.accent }]}
          height={300}
          cursor={showReplay ? idx : undefined}
          follow={showReplay && follow}
          zoom={7}
        />
      ) : (
        <View style={{ height: 300, borderRadius: 22, backgroundColor: '#15191D' }} />
      )}

      {/* Replay readout */}
      <Card style={{ marginTop: 12 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Pressable
            onPress={togglePlay}
            style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center', marginRight: 14 }}
          >
            <Ionicons name={playing ? 'pause' : 'play'} size={28} color="#fff" style={{ marginLeft: playing ? 0 : 3 }} />
          </Pressable>
          <View style={{ flexDirection: 'row', flex: 1 }}>
            <Stat label="Speed" value={cur ? fmtSpeed(cur.speed) : '0.0'} unit="km/h" />
            <Stat label="Elevation" value={cur ? String(Math.round(cur.alt)) : '0'} unit="m" />
            <Stat label="Distance" value={cur ? fmtKm(cur.dist) : '0.00'} unit="km" />
          </View>
        </View>
        <View style={{ flexDirection: 'row', marginTop: 14 }}>
          <Pill icon="videocam" label="Follow cam" selected={follow} onPress={() => setFollow((f) => !f)} />
          <Pill label={`${rate}x`} onPress={() => setRate((r) => (r === 1 ? 2 : r === 2 ? 4 : 1))} />
        </View>
      </Card>

      <SectionHeader title="Summary" />
      <Card>
        <View style={{ flexDirection: 'row' }}>
          <Stat big label="Distance" value={fmtKm(st.distance)} unit="km" />
          <Stat big label="Moving time" value={fmtDuration(st.movingTime)} />
        </View>
        <View style={{ height: 16 }} />
        <View style={{ flexDirection: 'row' }}>
          <Stat label="Avg speed" value={fmtSpeed(st.avgSpeed)} unit="km/h" />
          <Stat label="Top speed" value={fmtSpeed(st.maxSpeed)} unit="km/h" />
          <Stat label="Climb" value={String(Math.round(st.elevGain))} unit="m" />
        </View>
        <View style={{ height: 16 }} />
        <View style={{ flexDirection: 'row' }}>
          <Stat label="Elapsed" value={fmtClock(st.elapsed)} />
          <Stat label="Lowest" value={String(Math.round(st.minAlt))} unit="m" />
          <Stat label="Highest" value={String(Math.round(st.maxAlt))} unit="m" />
        </View>
      </Card>

      <SectionHeader title="Elevation" />
      <Sparkline values={alts} color={colors.good} id="elev" cursorFrac={showReplay ? progress : undefined} />
      <SectionHeader title="Speed" />
      <Sparkline values={speeds} color={colors.accent} id="spd" cursorFrac={showReplay ? progress : undefined} />
    </Screen>
  );
}
