import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Card, SectionHeader } from '../components';
import { colors, font } from '../theme';
import { getSettings, saveSettings, defaultSettings } from '../storage';

export default function SettingsScreen() {
  const [s, setS] = useState(defaultSettings);

  useEffect(() => { getSettings().then(setS); }, []);

  const update = (patch) => {
    const next = { ...s, ...patch };
    setS(next);
    saveSettings(next);
  };

  return (
    <Screen>
      <Text style={font.h1}>Settings</Text>

      <SectionHeader title="Streak" />
      <Card>
        <Row
          icon="flame"
          title="Minimum ride for streak"
          sub="A day counts if you ride at least this far"
          value={`${s.minStreakKm} km`}
          onMinus={() => update({ minStreakKm: Math.max(0.5, +(s.minStreakKm - 0.5).toFixed(1)) })}
          onPlus={() => update({ minStreakKm: Math.min(50, +(s.minStreakKm + 0.5).toFixed(1)) })}
        />
      </Card>

      <SectionHeader title="Recording" />
      <Card>
        <Row
          icon="pause-circle"
          title="Auto-pause below"
          sub="Slower than this counts as stopped"
          value={`${s.autoPauseKmh.toFixed(1)} km/h`}
          onMinus={() => update({ autoPauseKmh: Math.max(1, +(s.autoPauseKmh - 0.5).toFixed(1)) })}
          onPlus={() => update({ autoPauseKmh: Math.min(10, +(s.autoPauseKmh + 0.5).toFixed(1)) })}
        />
        <Text style={[font.small, { marginTop: 10 }]}>Applies to new rides and replays.</Text>
      </Card>

      <SectionHeader title="Laptop sync" />
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
          <Ionicons name="server" size={22} color={colors.accent} style={{ width: 34 }} />
          <View style={{ flex: 1 }}>
            <Text style={font.title}>Server address</Text>
            <Text style={font.small}>Coming in the next version</Text>
          </View>
        </View>
        <TextInput
          value={s.serverUrl}
          onChangeText={(v) => update({ serverUrl: v })}
          placeholder="http://100.x.x.x:8080"
          placeholderTextColor={colors.textDim}
          autoCapitalize="none"
          style={{ backgroundColor: colors.pill, borderRadius: 14, paddingHorizontal: 14, height: 48, color: colors.text, fontSize: 16 }}
        />
      </Card>
    </Screen>
  );
}

function Row({ icon, title, sub, value, onMinus, onPlus }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Ionicons name={icon} size={24} color={colors.accent} style={{ width: 34 }} />
      <View style={{ flex: 1, paddingRight: 8 }}>
        <Text style={font.title}>{title}</Text>
        <Text style={font.small}>{sub}</Text>
      </View>
      <Pressable onPress={onMinus} hitSlop={8} style={btn}><Ionicons name="remove" size={20} color={colors.text} /></Pressable>
      <Text style={{ color: colors.text, fontWeight: '700', width: 78, textAlign: 'center' }}>{value}</Text>
      <Pressable onPress={onPlus} hitSlop={8} style={btn}><Ionicons name="add" size={20} color={colors.text} /></Pressable>
    </View>
  );
}

const btn = { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.pill, alignItems: 'center', justifyContent: 'center' };
