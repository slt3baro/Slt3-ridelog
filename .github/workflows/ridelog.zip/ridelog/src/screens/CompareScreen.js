import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { Screen, Card, SectionHeader, RouteView, useAppData } from '../components';
import { colors, font } from '../theme';
import { getRidePoints } from '../storage';
import { decimate, fmtKm, fmtSpeed, fmtDuration, fmtDate, LAT, LON } from '../geo';

export default function CompareScreen() {
  const { rides } = useAppData();
  const [aId, setA] = useState(null);
  const [bId, setB] = useState(null);
  const [coords, setCoords] = useState({ a: [], b: [] });

  // Default: the two most recent rides (latest vs the one before).
  useEffect(() => {
    if (rides.length >= 2 && !aId && !bId) { setA(rides[0].id); setB(rides[1].id); }
    else if (rides.length === 1 && !aId) setA(rides[0].id);
  }, [rides]);

  useEffect(() => {
    (async () => {
      const load = async (id) => (id ? decimate(await getRidePoints(id), 500).map((p) => [p[LAT], p[LON]]) : []);
      setCoords({ a: await load(aId), b: await load(bId) });
    })();
  }, [aId, bId]);

  const A = rides.find((r) => r.id === aId);
  const B = rides.find((r) => r.id === bId);

  const rows = useMemo(() => {
    if (!A || !B) return [];
    const a = A.stats, b = B.stats;
    // higherIsBetter: true / false / null (neutral)
    return [
      { label: 'Distance', a: `${fmtKm(a.distance)} km`, b: `${fmtKm(b.distance)} km`, d: a.distance - b.distance, fmt: (v) => `${(Math.abs(v) / 1000).toFixed(2)} km`, better: true },
      { label: 'Moving time', a: fmtDuration(a.movingTime), b: fmtDuration(b.movingTime), d: a.movingTime - b.movingTime, fmt: (v) => fmtDuration(Math.abs(v)), better: null },
      { label: 'Avg speed', a: `${fmtSpeed(a.avgSpeed)} km/h`, b: `${fmtSpeed(b.avgSpeed)} km/h`, d: a.avgSpeed - b.avgSpeed, fmt: (v) => `${(Math.abs(v) * 3.6).toFixed(1)} km/h`, better: true },
      { label: 'Top speed', a: `${fmtSpeed(a.maxSpeed)} km/h`, b: `${fmtSpeed(b.maxSpeed)} km/h`, d: a.maxSpeed - b.maxSpeed, fmt: (v) => `${(Math.abs(v) * 3.6).toFixed(1)} km/h`, better: true },
      { label: 'Climbing', a: `${Math.round(a.elevGain)} m`, b: `${Math.round(b.elevGain)} m`, d: a.elevGain - b.elevGain, fmt: (v) => `${Math.round(Math.abs(v))} m`, better: null },
    ];
  }, [A, B]);

  if (rides.length < 2) {
    return (
      <Screen>
        <Text style={font.h1}>Compare</Text>
        <Card style={{ marginTop: 16 }}>
          <Text style={font.body}>Record at least two rides and you will be able to compare them here: routes on top of each other and every stat side by side.</Text>
        </Card>
      </Screen>
    );
  }

  return (
    <Screen>
      <Text style={font.h1}>Compare</Text>

      <Picker label="Ride A" color={colors.accent} rides={rides} selected={aId} onSelect={setA} />
      <Picker label="Ride B" color={colors.second} rides={rides} selected={bId} onSelect={setB} />

      {coords.a.length > 1 && coords.b.length > 1 && (
        <View style={{ marginTop: 16 }}>
          <RouteView
            height={260}
            routes={[
              { coords: coords.a, color: colors.accent },
              { coords: coords.b, color: colors.second },
            ]}
          />
        </View>
      )}

      {A && B && (
        <>
          <SectionHeader title="Side by side" />
          <Card>
            <View style={{ flexDirection: 'row', marginBottom: 6 }}>
              <Text style={[font.small, { flex: 1.2 }]} />
              <Text style={[font.small, { flex: 1, color: colors.accent, fontWeight: '700' }]}>A</Text>
              <Text style={[font.small, { flex: 1, color: colors.second, fontWeight: '700' }]}>B</Text>
              <Text style={[font.small, { flex: 1, textAlign: 'right' }]}>A vs B</Text>
            </View>
            {rows.map((r, i) => {
              const diff = Math.abs(r.d) < 1e-6 ? null : r.d;
              let c = colors.textDim;
              if (diff != null && r.better != null) c = (diff > 0) === r.better ? colors.good : colors.bad;
              return (
                <View key={i} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderTopWidth: 1, borderTopColor: colors.border }}>
                  <Text style={[font.body, { flex: 1.2 }]}>{r.label}</Text>
                  <Text style={{ flex: 1, color: colors.text, fontWeight: '600' }}>{r.a}</Text>
                  <Text style={{ flex: 1, color: colors.text, fontWeight: '600' }}>{r.b}</Text>
                  <Text style={{ flex: 1, textAlign: 'right', color: c, fontWeight: '700' }}>
                    {diff == null ? '-' : `${diff > 0 ? '+' : '-'}${r.fmt(diff)}`}
                  </Text>
                </View>
              );
            })}
          </Card>
        </>
      )}
    </Screen>
  );
}

function Picker({ label, color, rides, selected, onSelect }) {
  return (
    <View style={{ marginTop: 16 }}>
      <Text style={[font.small, { color, fontWeight: '700', marginBottom: 8 }]}>{label}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -16 }} contentContainerStyle={{ paddingHorizontal: 16 }}>
        {rides.map((r) => {
          const on = r.id === selected;
          return (
            <Pressable
              key={r.id}
              onPress={() => onSelect(r.id)}
              style={{
                marginRight: 10, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 16,
                backgroundColor: on ? color + '33' : colors.pill, borderWidth: on ? 1.5 : 0, borderColor: color,
              }}
            >
              <Text style={{ color: colors.text, fontWeight: '600' }}>{fmtDate(r.startedAt)}</Text>
              <Text style={font.small}>{fmtKm(r.stats.distance)} km</Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}
