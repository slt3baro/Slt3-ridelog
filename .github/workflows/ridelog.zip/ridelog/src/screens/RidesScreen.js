import React, { useState, useMemo } from 'react';
import { View, Text, Pressable } from 'react-native';
import { Screen, SearchBar, Pill, RouteThumb, useAppData } from '../components';
import { colors, font } from '../theme';
import { fmtKm, fmtDuration, fmtDate, fmtTime, fmtSpeed, currentWeek } from '../geo';

export default function RidesScreen({ navigation }) {
  const { rides } = useAppData();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all');

  const list = useMemo(() => {
    const now = new Date();
    const weekStart = currentWeek()[0].ms - 12 * 3600 * 1000;
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    return rides.filter((r) => {
      if (filter === 'week' && r.startedAt < weekStart) return false;
      if (filter === 'month' && r.startedAt < monthStart) return false;
      if (q && !r.name.toLowerCase().includes(q.toLowerCase()) && !fmtDate(r.startedAt).toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    });
  }, [rides, q, filter]);

  return (
    <Screen>
      <SearchBar value={q} onChangeText={setQ} placeholder="Search rides..." />
      <View style={{ flexDirection: 'row', marginBottom: 18 }}>
        <Pill label="All" selected={filter === 'all'} onPress={() => setFilter('all')} />
        <Pill label="This week" selected={filter === 'week'} onPress={() => setFilter('week')} />
        <Pill label="This month" selected={filter === 'month'} onPress={() => setFilter('month')} />
      </View>

      {list.length === 0 && <Text style={[font.body, { textAlign: 'center', marginTop: 40 }]}>No rides to show yet.</Text>}

      {list.map((r) => (
        <Pressable
          key={r.id}
          onPress={() => navigation.navigate('RideDetail', { id: r.id })}
          style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border }}
        >
          <RouteThumb coords={r.preview} size={72} />
          <View style={{ flex: 1, marginLeft: 14 }}>
            <Text style={font.h2} numberOfLines={1}>{r.name}</Text>
            <Text style={font.body}>{fmtDate(r.startedAt)} · {fmtTime(r.startedAt)}</Text>
            <Text style={{ color: colors.accent, fontSize: 14, marginTop: 2 }}>
              {fmtKm(r.stats.distance)} km · {fmtSpeed(r.stats.avgSpeed)} km/h avg
            </Text>
          </View>
          <Text style={[font.body, { fontSize: 17 }]}>{fmtDuration(r.stats.movingTime)}</Text>
        </Pressable>
      ))}
    </Screen>
  );
}
