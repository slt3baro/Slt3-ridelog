import React from 'react';
import { View, Text, FlatList, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Card, SectionHeader, IconStat, RouteThumb, SearchBar, Pill, useAppData } from '../components';
import { colors, font } from '../theme';
import { computeStreak, currentWeek, fmtKm, fmtDuration, fmtSpeed, fmtDate, dayKey } from '../geo';

export default function HomeScreen({ navigation }) {
  const { rides, settings } = useAppData();
  const streak = computeStreak(rides, settings.minStreakKm * 1000);
  const week = currentWeek();

  const totalDist = rides.reduce((s, r) => s + r.stats.distance, 0);
  const totalMoving = rides.reduce((s, r) => s + r.stats.movingTime, 0);
  const weekStart = week[0].ms - 12 * 3600 * 1000;
  const weekDist = rides.filter((r) => r.startedAt >= weekStart).reduce((s, r) => s + r.stats.distance, 0);

  const longest = rides.reduce((b, r) => (!b || r.stats.distance > b.stats.distance ? r : b), null);
  const fastest = rides.reduce((b, r) => (!b || r.stats.maxSpeed > b.stats.maxSpeed ? r : b), null);
  const bestAvg = rides.reduce((b, r) => (!b || r.stats.avgSpeed > b.stats.avgSpeed ? r : b), null);
  const climb = rides.reduce((b, r) => (!b || r.stats.elevGain > b.stats.elevGain ? r : b), null);

  return (
    <Screen>
      <SearchBar placeholder="Search rides..." />
      <View style={{ flexDirection: 'row' }}>
        <Pill icon="bicycle" label="New ride" onPress={() => navigation.navigate('Record')} />
        <Pill icon="git-compare" label="Compare" onPress={() => navigation.navigate('Compare')} />
      </View>

      <SectionHeader title="My Riding" />
      <Card style={{ flexDirection: 'row', paddingVertical: 22 }}>
        <IconStat icon="bicycle" value={String(rides.length)} label="rides" />
        <IconStat icon="speedometer" value={`${(totalDist / 1000).toFixed(0)} km`} label="distance" />
        <IconStat icon="time" value={fmtDuration(totalMoving)} label="moving" />
        <IconStat icon="flame" value={`${streak.current}d`} label="streak" color={streak.current > 0 ? colors.warn : colors.accent} />
      </Card>

      <SectionHeader title="This Week" right={<Text style={font.body}>{(weekDist / 1000).toFixed(1)} km</Text>} />
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          {week.map((d, i) => {
            const done = streak.ridden(d.ms);
            return (
              <View key={i} style={{ alignItems: 'center', flex: 1 }}>
                <Text style={[font.small, d.isToday && { color: colors.accent, fontWeight: '700' }]}>{d.label}</Text>
                <View
                  style={{
                    marginTop: 8, width: 38, height: 38, borderRadius: 19,
                    backgroundColor: done ? colors.accent : colors.pill,
                    borderWidth: d.isToday ? 2 : 0, borderColor: colors.accent,
                    alignItems: 'center', justifyContent: 'center',
                  }}
                >
                  {done && <Ionicons name="checkmark" size={22} color="#fff" />}
                </View>
              </View>
            );
          })}
        </View>
        <Text style={[font.small, { marginTop: 14 }]}>
          Best streak: {streak.best} days · counts rides of {settings.minStreakKm} km or more
        </Text>
      </Card>

      <SectionHeader title="Recent Rides" />
      {rides.length === 0 ? (
        <Card><Text style={font.body}>No rides yet. Tap "New ride" to record your first one.</Text></Card>
      ) : (
        <FlatList
          horizontal
          data={rides.slice(0, 8)}
          keyExtractor={(r) => r.id}
          showsHorizontalScrollIndicator={false}
          style={{ marginHorizontal: -16 }}
          contentContainerStyle={{ paddingHorizontal: 16 }}
          renderItem={({ item }) => (
            <Card onPress={() => navigation.navigate('RideDetail', { id: item.id })} style={{ width: 190, marginRight: 12, padding: 12 }}>
              <RouteThumb coords={item.preview} size={166} />
              <Text style={[font.title, { marginTop: 10 }]} numberOfLines={1}>{item.name}</Text>
              <Text style={font.body}>{fmtKm(item.stats.distance)} km · {fmtDate(item.startedAt)}</Text>
            </Card>
          )}
        />
      )}

      {rides.length > 0 && (
        <>
          <SectionHeader title="Personal Bests" />
          <Card style={{ paddingVertical: 4 }}>
            <Best icon="trophy" label="Longest ride" value={`${fmtKm(longest.stats.distance)} km`} sub={fmtDate(longest.startedAt)} />
            <Best icon="flash" label="Top speed" value={`${fmtSpeed(fastest.stats.maxSpeed)} km/h`} sub={fmtDate(fastest.startedAt)} />
            <Best icon="speedometer" label="Best average" value={`${fmtSpeed(bestAvg.stats.avgSpeed)} km/h`} sub={fmtDate(bestAvg.startedAt)} />
            <Best icon="trending-up" label="Most climbing" value={`${Math.round(climb.stats.elevGain)} m`} sub={fmtDate(climb.startedAt)} last />
          </Card>
        </>
      )}
    </Screen>
  );
}

function Best({ icon, label, value, sub, last }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: last ? 0 : 1, borderBottomColor: colors.border }}>
      <Ionicons name={icon} size={22} color={colors.accent} style={{ width: 36 }} />
      <View style={{ flex: 1 }}>
        <Text style={font.title}>{label}</Text>
        <Text style={font.small}>{sub}</Text>
      </View>
      <Text style={[font.title, { color: colors.accent }]}>{value}</Text>
    </View>
  );
}
