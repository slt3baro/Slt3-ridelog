import React, { useEffect, useRef, useState, useCallback } from 'react';
import { View, Text, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { Screen, Card, Stat, Button, RouteView } from '../components';
import { colors, font } from '../theme';
import { computeStats, isAutoPaused, decimate, fmtClock, fmtSpeed, fmtKm, T, LAT, LON, SPD } from '../geo';
import { startRide, setPaused, readActive, finishRide } from '../tracking';
import { saveRide, getSettings } from '../storage';

export default function RecordScreen({ navigation }) {
  const [active, setActive] = useState(null); // { meta, points } or null
  const [thresholdMps, setThreshold] = useState(1.0);
  const [busy, setBusy] = useState(false);
  const [warn, setWarn] = useState('');
  const timer = useRef(null);

  const refresh = useCallback(async () => {
    setActive(await readActive());
  }, []);

  useFocusEffect(
    useCallback(() => {
      getSettings().then((s) => setThreshold(s.autoPauseKmh / 3.6));
      refresh();
      timer.current = setInterval(refresh, 1000);
      return () => clearInterval(timer.current);
    }, [refresh])
  );

  const onStart = async () => {
    setBusy(true);
    setWarn('');
    try {
      const perm = await startRide();
      if (!perm.background) {
        setWarn('Tip: set Location to "Allow all the time" in Android settings so recording keeps going with the screen off.');
      }
      await refresh();
    } catch (e) {
      Alert.alert('Could not start', e.message || String(e));
    }
    setBusy(false);
  };

  const onPauseToggle = async () => {
    await setPaused(!active.meta.paused);
    await refresh();
  };

  const onStop = () => {
    Alert.alert('Finish ride?', 'Stop recording and save this ride.', [
      { text: 'Keep riding', style: 'cancel' },
      {
        text: 'Finish',
        style: 'default',
        onPress: async () => {
          setBusy(true);
          const points = await finishRide();
          setActive(null);
          const stats = computeStats(points, thresholdMps);
          if (points.length < 5 || stats.distance < 50) {
            Alert.alert('Ride too short', 'Under 50 m was recorded, so it was not saved.');
          } else {
            const saved = await saveRide(points, thresholdMps);
            navigation.navigate('RideDetail', { id: saved.id });
          }
          setBusy(false);
        },
      },
    ]);
  };

  // ---------- idle ----------
  if (!active) {
    return (
      <Screen scroll={false}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <View style={{ width: 150, height: 150, borderRadius: 75, backgroundColor: colors.accentSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 28 }}>
            <Ionicons name="bicycle" size={78} color={colors.accent} />
          </View>
          <Text style={font.h1}>Ready to ride?</Text>
          <Text style={[font.body, { textAlign: 'center', marginTop: 8, marginBottom: 32, paddingHorizontal: 24 }]}>
            Your route, speed and elevation are recorded, and the timer pauses by itself when you stop.
          </Text>
          <Button title={busy ? 'Starting...' : 'Start ride'} icon="play" onPress={onStart} disabled={busy} style={{ width: 240 }} />
          {warn ? <Text style={[font.small, { textAlign: 'center', marginTop: 18, paddingHorizontal: 24 }]}>{warn}</Text> : null}
        </View>
      </Screen>
    );
  }

  // ---------- recording ----------
  const pts = active.points;
  const stats = computeStats(pts, thresholdMps);
  const manualPaused = active.meta.paused;
  const autoPaused = !manualPaused && pts.length > 2 && isAutoPaused(pts, thresholdMps);
  const last = pts[pts.length - 1];
  const fresh = last && Date.now() - last[T] < 6000;
  const curMps = !manualPaused && !autoPaused && fresh && last[SPD] != null && last[SPD] >= 0 ? last[SPD] : 0;
  const coords = decimate(pts, 400).map((p) => [p[LAT], p[LON]]);
  const status = manualPaused ? 'Paused' : autoPaused ? 'Auto-paused' : pts.length === 0 ? 'Waiting for GPS...' : 'Recording';
  const statusColor = manualPaused || autoPaused ? colors.warn : pts.length === 0 ? colors.textDim : colors.good;

  return (
    <Screen scroll={false}>
      <View style={{ alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', backgroundColor: colors.pill, borderRadius: 999, paddingHorizontal: 14, height: 36, marginBottom: 14 }}>
        <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: statusColor, marginRight: 8 }} />
        <Text style={{ color: colors.text, fontWeight: '600' }}>{status}</Text>
      </View>

      <View style={{ alignItems: 'center', marginVertical: 6 }}>
        <Text style={font.big}>{fmtSpeed(curMps)}</Text>
        <Text style={font.body}>km/h</Text>
      </View>

      <Card style={{ flexDirection: 'row', marginTop: 12 }}>
        <Stat label="Distance" value={fmtKm(stats.distance)} unit="km" />
        <Stat label="Moving time" value={fmtClock(stats.movingTime)} />
      </Card>
      <Card style={{ flexDirection: 'row', marginTop: 10 }}>
        <Stat label="Avg speed" value={fmtSpeed(stats.avgSpeed)} unit="km/h" />
        <Stat label="Top speed" value={fmtSpeed(stats.maxSpeed)} unit="km/h" />
        <Stat label="Elevation" value={String(Math.round(last && last[3] != null ? last[3] : 0))} unit="m" />
      </Card>

      <View style={{ flex: 1, marginTop: 12, marginBottom: 12 }}>
        {coords.length > 1 ? (
          <RouteView routes={[{ coords, color: colors.accent }]} height={190} cursor={coords.length - 1} follow zoom={3} />
        ) : (
          <View style={{ height: 190, borderRadius: 22, backgroundColor: '#15191D', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={font.body}>Your route will appear here</Text>
          </View>
        )}
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'center', marginBottom: 12 }}>
        <Button
          title={manualPaused ? 'Resume' : 'Pause'}
          icon={manualPaused ? 'play' : 'pause'}
          onPress={onPauseToggle}
          color={colors.pill}
          style={{ flex: 1, marginRight: 10 }}
        />
        <Button title="Finish" icon="stop" onPress={onStop} color={colors.bad} style={{ flex: 1 }} disabled={busy} />
      </View>
    </Screen>
  );
}
