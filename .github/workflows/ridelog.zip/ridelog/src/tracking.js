// Background GPS recording. This file must be imported once at app start (App.js does it)
// because the task has to be defined before Android wakes the app in the background.
import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const TASK = 'ridelog-location-task';
const META = 'active:meta';
const CHUNK = (n) => `active:chunk:${n}`;
const CHUNK_SIZE = 200;

async function getMeta() {
  const raw = await AsyncStorage.getItem(META);
  return raw ? JSON.parse(raw) : null;
}

async function appendPoints(newPoints) {
  const meta = await getMeta();
  if (!meta || meta.paused) return;
  const raw = await AsyncStorage.getItem(CHUNK(meta.chunk));
  let chunk = raw ? JSON.parse(raw) : [];
  for (const p of newPoints) {
    p[5] = meta.seg;
    chunk.push(p);
    if (chunk.length >= CHUNK_SIZE) {
      await AsyncStorage.setItem(CHUNK(meta.chunk), JSON.stringify(chunk));
      meta.chunk += 1;
      chunk = [];
    }
  }
  await AsyncStorage.setItem(CHUNK(meta.chunk), JSON.stringify(chunk));
  await AsyncStorage.setItem(META, JSON.stringify(meta));
}

TaskManager.defineTask(TASK, async ({ data, error }) => {
  if (error || !data) return;
  const pts = [];
  for (const l of data.locations || []) {
    const c = l.coords;
    if (c.accuracy != null && c.accuracy > 35) continue; // ignore poor fixes
    pts.push([l.timestamp, c.latitude, c.longitude, c.altitude, c.speed, 0]);
  }
  if (pts.length) await appendPoints(pts);
});

export async function ensurePermissions() {
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') return { ok: false, reason: 'Location permission is needed to record rides.' };
  // Background permission lets recording continue with the screen off.
  const bg = await Location.requestBackgroundPermissionsAsync();
  return { ok: true, background: bg.status === 'granted' };
}

export async function isRecording() {
  const meta = await getMeta();
  return !!meta;
}

export async function startRide() {
  const perm = await ensurePermissions();
  if (!perm.ok) throw new Error(perm.reason);
  await AsyncStorage.setItem(META, JSON.stringify({ startedAt: Date.now(), chunk: 0, seg: 0, paused: false }));
  await AsyncStorage.removeItem(CHUNK(0));
  await Location.startLocationUpdatesAsync(TASK, {
    accuracy: Location.Accuracy.BestForNavigation,
    timeInterval: 1000,
    distanceInterval: 0,
    pausesUpdatesAutomatically: false,
    showsBackgroundLocationIndicator: true,
    foregroundService: {
      notificationTitle: 'RideLog is recording',
      notificationBody: 'Your ride is being tracked.',
      notificationColor: '#2196F3',
    },
  });
  return perm;
}

export async function setPaused(paused) {
  const meta = await getMeta();
  if (!meta) return;
  meta.paused = paused;
  if (!paused) meta.seg += 1; // new segment so the gap is never counted as riding
  await AsyncStorage.setItem(META, JSON.stringify(meta));
}

export async function readActive() {
  const meta = await getMeta();
  if (!meta) return null;
  const keys = Array.from({ length: meta.chunk + 1 }, (_, i) => CHUNK(i));
  const pairs = await AsyncStorage.multiGet(keys);
  const points = [];
  for (const [, v] of pairs) if (v) points.push(...JSON.parse(v));
  return { meta, points };
}

async function clearActive() {
  const meta = await getMeta();
  if (meta) {
    const keys = Array.from({ length: meta.chunk + 1 }, (_, i) => CHUNK(i));
    await AsyncStorage.multiRemove([...keys, META]);
  }
}

// Stops recording and returns the points. Does not save them; the caller decides.
export async function finishRide() {
  try {
    if (await Location.hasStartedLocationUpdatesAsync(TASK)) {
      await Location.stopLocationUpdatesAsync(TASK);
    }
  } catch {}
  const active = await readActive();
  await clearActive();
  return active ? active.points : [];
}
