# RideLog

A free bike tracker for Android: records your route, speed and elevation, auto-pauses when you stop,
keeps a streak, replays rides as a follow-cam animation, and compares any two rides.

## What is in version 1

- **Record**: GPS route, speed, elevation, moving time, average and top speed. Keeps recording with the screen off.
- **Auto-pause**: the timer stops by itself when you stop moving (threshold adjustable in Settings). There is also a manual Pause button.
- **Home**: totals, streak with a Sunday-to-Saturday week strip, recent rides, personal bests.
- **Rides**: searchable history with route thumbnails.
- **Ride detail**: route replay with follow cam, live speed/elevation/distance readout, elevation and speed charts.
- **Compare**: pick two rides, see the routes overlaid and every stat side by side.
- Data is stored on the phone. Laptop sync and the home-screen streak widget are next.

## Run it on your phone (pick one)

This app needs a real build, not Expo Go (Expo Go cannot do background GPS).

### Option A: USB cable from your PC
1. Install **Node.js LTS** and **Android Studio** (it brings the Android SDK and Java).
2. On the phone: Settings > About phone > tap "Build number" 7 times, then Developer options > turn on **USB debugging**.
3. Plug the phone in and accept the prompt on it.
4. In this folder:
   ```
   npm install
   npx expo run:android
   ```
   The first build takes several minutes. After that the app is installed on the phone.

### Option B: Cloud build (no Android SDK needed)
```
npm install
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```
When it finishes, open the link it prints on your phone, download the APK and install it.

## First ride checklist
- Allow location, then choose **Allow all the time** so recording continues with the screen off.
- On Samsung, Xiaomi, Oppo and similar phones, set RideLog's battery usage to **Unrestricted**,
  or Android may stop the recording mid-ride.
- Test with a short ride first and tell me what looked wrong.

## Code map
- `App.js`: navigation (tabs plus the ride detail screen)
- `src/tracking.js`: background GPS recording
- `src/geo.js`: distance, moving time, speeds, elevation gain, streaks (tested)
- `src/storage.js`: rides and settings saved on the phone
- `src/components.js`: shared UI, route drawing, charts
- `src/theme.js`: colors and fonts (change the accent color here)
- `src/screens/`: Home, Record, Rides, RideDetail, Compare, Settings
