import React from 'react';
import { registerRootComponent } from 'expo';
import { installGlobalHandler, ErrorBoundary, CrashView } from './src/crash';

installGlobalHandler();

// App is loaded inside try/catch so a failing module shows its error on screen
// instead of closing the app.
let Root;
try {
  Root = require('./App').default;
} catch (e) {
  const text = e && e.stack ? `${e.message}\n\n${e.stack}` : String(e);
  Root = () => <CrashView text={text} />;
}

registerRootComponent(() => (
  <ErrorBoundary>
    <Root />
  </ErrorBoundary>
));
