// Shows JavaScript errors on screen instead of silently closing the app.
// Must not import anything native, so it still works if another module fails to load.
import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';

let showError = null;

export function installGlobalHandler() {
  const EU = global.ErrorUtils;
  if (!EU || !EU.setGlobalHandler) return;
  const prev = EU.getGlobalHandler && EU.getGlobalHandler();
  EU.setGlobalHandler((error, isFatal) => {
    if (isFatal && showError) {
      showError(describe(error));
    } else if (prev) {
      prev(error, isFatal);
    }
  });
}

function describe(e) {
  if (e && e.stack) return `${e.message || ''}\n\n${e.stack}`;
  return String(e);
}

export function CrashView({ text, onRetry }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#121212', paddingTop: 56, paddingHorizontal: 16 }}>
      <Text style={{ color: '#EF5350', fontSize: 22, fontWeight: '700', marginBottom: 6 }}>RideLog hit an error</Text>
      <Text style={{ color: '#A5A8AE', marginBottom: 12 }}>Send a screenshot of this screen so it can be fixed.</Text>
      <ScrollView style={{ flex: 1, backgroundColor: '#1C1C1E', borderRadius: 12, padding: 12 }}>
        <Text selectable style={{ color: '#fff', fontSize: 12 }}>{text}</Text>
      </ScrollView>
      {onRetry ? (
        <Pressable onPress={onRetry} style={{ backgroundColor: '#2196F3', borderRadius: 999, height: 52, alignItems: 'center', justifyContent: 'center', marginVertical: 16 }}>
          <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>Try again</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export class ErrorBoundary extends React.Component {
  state = { error: null };

  static getDerivedStateFromError(e) {
    return { error: describe(e) };
  }

  componentDidMount() {
    showError = (t) => this.setState({ error: t });
  }

  componentWillUnmount() {
    showError = null;
  }

  render() {
    if (this.state.error) {
      return <CrashView text={this.state.error} onRetry={() => this.setState({ error: null })} />;
    }
    return this.props.children;
  }
}
